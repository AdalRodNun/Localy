package com.example.proyect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class SERVICIO_ACTIVITY : AppCompatActivity() {
    lateinit var servicio1: TextView
    lateinit var servicio2: TextView
    lateinit var servicio3: TextView
    lateinit var infoServicio: TextView
    lateinit var nombre : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicio)

        servicio1 = findViewById(R.id.servicio_text_1)
        servicio2 = findViewById(R.id.servicio_text_2)
        servicio3 = findViewById(R.id.servicio_text_3)
        infoServicio = findViewById(R.id.info_text_1)
        nombre = findViewById(R.id.nombre_text)

    }

    /*fun registrarDatos() {
        val servicio = hashMapOf(
            "servicio 1" to servicio1.text.toString(),
            "servicio 2" to servicio2.text.toString(),
            "servicio 3" to servicio3.text.toString(),
            "informacion servicio" to infoServicio.text.toString()
        )

        Firebase.firestore.collection("servicios")
            .add(servicio)
            .addOnSuccessListener {

                Log.d("FIREBASE", "id: ${it.id}")
            }
            .addOnFailureListener {

                Log.e("FIREBASE", "exception: ${it.message}")
            }
    }*/

    fun leerDatos() {
        Firebase.firestore.collection("servicios")
            .get()
            .addOnSuccessListener {
                for (documento in it) {
                    if(documento.id == intent.getStringExtra("code")){
                        nombre.text = documento.data["nombre"].toString()
                        servicio1.text = documento.data["servicio 1"].toString()
                        servicio2.text = documento.data["servicio 2"].toString()
                        servicio3.text = documento.data["servicio 3"].toString()
                        infoServicio.text = documento.data["informacion servicio"].toString()
                    }
                }
            }
            .addOnFailureListener() {
                Log.e("FIRESTORE", "error al leer servicios: ${it.message}")
            }
    }

    override fun onStart(){
        super.onStart()
        leerDatos()
    }
}