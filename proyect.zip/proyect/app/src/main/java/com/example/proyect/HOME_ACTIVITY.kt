package com.example.proyect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class HOME_ACTIVITY : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }

    public fun Marcos(v : View?) {
        val intent = Intent(this, SERVICIO_ACTIVITY::class.java)
        intent.putExtra("code", "oOuq2iCxPra5e2a3tyA7")
        startActivity(intent)
    }

    public fun Caravan(v : View?) {
        val intent = Intent(this, SERVICIO_ACTIVITY::class.java)
        intent.putExtra("code", "xUk6qVSCA5fcBEbVhNur")
        startActivity(intent)
    }

    public fun Plomeria(v : View?) {
        val intent = Intent(this, SERVICIO_ACTIVITY::class.java)
        intent.putExtra("code", "jPWAVPNnLp4ReTwM2atA")
        startActivity(intent)
    }
}