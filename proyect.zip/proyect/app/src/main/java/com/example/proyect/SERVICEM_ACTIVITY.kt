package com.example.proyect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class SERVICEM_ACTIVITY : AppCompatActivity() {
    lateinit var servicio1: TextView
    lateinit var servicio2: TextView
    lateinit var servicio3: TextView
    lateinit var infoServicio: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicem)

        servicio1 = findViewById(R.id.servicio_text_1)
        servicio2 = findViewById(R.id.servicio_text_2)
        servicio3 = findViewById(R.id.servicio_text_3)
        infoServicio = findViewById(R.id.info_text_1)
    }
    /*
    fun registrarDatos() {
        val servicio = hashMapOf(
            "servicio 1" to servicio1.text.toString(),
            "servicio 2" to servicio2.text.toString(),
            "servicio 3" to servicio3.text.toString(),
            "informacion servicio" to infoServicio.text.toString()
        )

        Firebase.firestore.collection("gatitos")
            .add(servicio)
            .addOnSuccessListener {

                Log.d("FIREBASE", "id: ${it.id}")
            }
            .addOnFailureListener {

                Log.e("FIREBASE", "exception: ${it.message}")
            }
    }

    fun leerDatos(view: View?) {
        Firebase.firestore.collection("gatitos")
            .get() //tod0 lo que haya
            .addOnSuccessListener {
                //reccorrer quey snapshot con un foreach
                for (documento in it) {
                    Log.d("FIRESTORE", "${documento.id} ${documento.data}")
                }
            }
            .addOnFailureListener() {
                Log.e("FIRESTORE", "error al leer gatitos: ${it.message}")
            }
    }
    */
    //override fun onStart(){
    //super.onStart()
    //  registrarDatos()
    //}
}